import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export type ItemType = 'fish' | 'trash' | 'treasure' | 'detector';

export interface Sandcastle {
  id: string;
  x: number;
  z: number;
  hasTreasure: boolean;
  dug: boolean;
}

export interface Item {
  id: string;
  name: string;
  type: ItemType;
  value: number;
  icon: string;
  description: string;
}

export const TASKS = [
  { id: 'fish', desc: '新手教程：试着钓一条鱼吧！', target: 1, reward: 20 },
  { id: 'sell', desc: '新手教程：去商店把战利品卖掉换钱。', target: 1, reward: 30 },
  { id: 'buy_detector', desc: '新手教程：在商店购买【古董探测器】。', target: 1, reward: 50 },
  { id: 'dig', desc: '新手教程：有了探测器，试着挖一次宝！', target: 1, reward: 50 },
  { id: 'share', desc: '新手教程：挖到好东西时，点击【炫耀】分享给朋友！', target: 1, reward: 100 },
  { id: 'upgrade', desc: '新手教程：在商店购买任意一项升级。', target: 1, reward: 100 },
  { id: 'unlock_island', desc: '进阶任务：攒钱解锁【迷雾森林岛】。', target: 1, reward: 500 },
  { id: 'done', desc: '你已完成所有教程，自由探索吧！', target: 1, reward: 0 }
];

export interface OtherPlayer {
  uid: string;
  displayName: string;
  photoURL?: string;
  island: string;
  x: number;
  z: number;
  rotationY: number;
  state: string;
  lastActive: any;
  emote?: string;
}

export interface ChatMessage {
  id: string;
  uid: string;
  displayName: string;
  text: string;
  timestamp: any;
  island: string;
}

interface GameState {
  money: number;
  inventory: Item[];
  currentIsland: string;
  detectorOwned: boolean;
  boatLevel: number;
  luckLevel: number;
  rodSpeedLevel: number;
  rodZoneLevel: number;
  fuel: number;
  playerState: 'idle' | 'fishing' | 'fish_biting' | 'digging' | 'trapped' | 'building' | 'shaking' | 'mining';
  messages: string[];
  unlockedIslands: string[];
  isSailing: boolean;
  collection: string[];
  showingItem: Item | null;
  currentEmote: string | null;
  isNearChest: boolean;
  questActive: boolean;
  questTimeLeft: number;
  sandcastles: Sandcastle[];
  currentTaskIndex: number;
  taskProgress: number;
  otherPlayers: OtherPlayer[];
  chatMessages: ChatMessage[];
  
  addMoney: (amount: number) => void;
  addItem: (item: Item) => void;
  removeItem: (id: string) => void;
  buyDetector: () => void;
  buyLuckUpgrade: () => void;
  buyRodSpeedUpgrade: () => void;
  buyRodZoneUpgrade: () => void;
  sellAll: () => void;
  setPlayerState: (state: 'idle' | 'fishing' | 'fish_biting' | 'digging' | 'trapped' | 'building' | 'shaking' | 'mining') => void;
  setIsland: (island: string) => void;
  unlockIsland: (islandId: string, cost: number) => void;
  setSailing: (isSailing: boolean) => void;
  buyBoatUpgrade: () => void;
  addMessage: (msg: string) => void;
  setShowingItem: (item: Item | null) => void;
  setEmote: (emote: string | null) => void;
  setIsNearChest: (near: boolean) => void;
  startQuest: () => void;
  digSandcastle: (id: string) => void;
  tickQuest: () => void;
  updateTask: (type: string, amount?: number) => void;
  claimTaskReward: () => void;
  setOtherPlayers: (players: OtherPlayer[]) => void;
  setChatMessages: (messages: ChatMessage[]) => void;
}

export const useGameStore = create<GameState>()(
  persist(
    (set, get) => ({
  money: 0,
  inventory: [],
  currentIsland: 'sand',
  detectorOwned: false,
  boatLevel: 1,
  luckLevel: 0,
  rodSpeedLevel: 0,
  rodZoneLevel: 0,
  fuel: 100,
  playerState: 'idle',
  messages: [],
  unlockedIslands: ['sand'],
  isSailing: false,
  collection: [],
  showingItem: null,
  currentEmote: null,
  isNearChest: false,
  questActive: false,
  questTimeLeft: 0,
  sandcastles: [],
  currentTaskIndex: 0,
  taskProgress: 0,
  otherPlayers: [],
  chatMessages: [],

  setOtherPlayers: (players) => set({ otherPlayers: players }),
  setChatMessages: (messages) => set({ chatMessages: messages }),

  updateTask: (type, amount = 1) => set((state) => {
    const task = TASKS[state.currentTaskIndex];
    if (!task || task.id !== type || task.id === 'done') return state;
    const newProgress = Math.min(task.target, state.taskProgress + amount);
    if (newProgress === task.target && state.taskProgress < task.target) {
      setTimeout(() => {
        useGameStore.getState().addMessage(`[系统] 任务完成！快去领取奖励吧！`);
      }, 100);
    }
    return { taskProgress: newProgress };
  }),

  claimTaskReward: () => set((state) => {
    const task = TASKS[state.currentTaskIndex];
    if (!task || state.taskProgress < task.target || task.id === 'done') return state;
    return {
      money: state.money + task.reward,
      currentTaskIndex: state.currentTaskIndex + 1,
      taskProgress: 0
    };
  }),

  addMoney: (amount) => set((state) => ({ money: state.money + amount })),
  addItem: (item) => set((state) => ({ 
    inventory: [...state.inventory, item],
    collection: state.collection.includes(item.name) ? state.collection : [...state.collection, item.name]
  })),
  removeItem: (id) => set((state) => ({ 
    inventory: state.inventory.filter(i => i.id !== id),
    showingItem: state.showingItem?.id === id ? null : state.showingItem
  })),
  buyDetector: () => {
    get().updateTask('buy_detector', 1);
    set((state) => {
      if (state.money >= 50 && !state.detectorOwned) {
        return { money: state.money - 50, detectorOwned: true };
      }
      return state;
    });
  },
  buyLuckUpgrade: () => {
    get().updateTask('upgrade', 1);
    set((state) => {
      const cost = 100 * Math.pow(2, state.luckLevel);
      if (state.money >= cost) {
        return { money: state.money - cost, luckLevel: state.luckLevel + 1 };
      }
      return state;
    });
  },
  buyRodSpeedUpgrade: () => {
    get().updateTask('upgrade', 1);
    set((state) => {
      const cost = 100 * Math.pow(2, state.rodSpeedLevel);
      if (state.money >= cost && state.rodSpeedLevel < 5) {
        return { money: state.money - cost, rodSpeedLevel: state.rodSpeedLevel + 1 };
      }
      return state;
    });
  },
  buyRodZoneUpgrade: () => {
    get().updateTask('upgrade', 1);
    set((state) => {
      const cost = 100 * Math.pow(2, state.rodZoneLevel);
      if (state.money >= cost && state.rodZoneLevel < 5) {
        return { money: state.money - cost, rodZoneLevel: state.rodZoneLevel + 1 };
      }
      return state;
    });
  },
  sellAll: () => {
    const itemCount = get().inventory.length;
    get().updateTask('sell', itemCount);
    set((state) => {
      const totalValue = state.inventory.reduce((sum, item) => sum + item.value, 0);
      return { money: state.money + totalValue, inventory: [], showingItem: null };
    });
  },
  setPlayerState: (playerState) => set({ playerState }),
  setIsland: (island) => set({ currentIsland: island }),
  unlockIsland: (islandId, cost) => {
    if (islandId === 'forest') get().updateTask('unlock_island', 1);
    set((state) => {
      if (state.money >= cost && !state.unlockedIslands.includes(islandId)) {
        return { money: state.money - cost, unlockedIslands: [...state.unlockedIslands, islandId] };
      }
      return state;
    });
  },
  setSailing: (isSailing) => set({ isSailing }),
  buyBoatUpgrade: () => set((state) => {
    if (state.money >= 500 && state.boatLevel === 1) {
      return { money: state.money - 500, boatLevel: 2 };
    }
    return state;
  }),
  addMessage: (msg) => set((state) => ({ 
    messages: [...state.messages.slice(-4), msg] 
  })),
  setShowingItem: (item) => set({ showingItem: item }),
  setEmote: (emote) => set({ currentEmote: emote }),
  setIsNearChest: (near) => set({ isNearChest: near }),
  startQuest: () => set((state) => {
    if (state.questActive) return state;
    const castles = [];
    for (let i=0; i<15; i++) {
      const angle = Math.random() * Math.PI * 2;
      const radius = 3 + Math.random() * 6;
      castles.push({
        id: `sc_${i}`,
        x: Math.cos(angle) * radius,
        z: Math.sin(angle) * radius,
        hasTreasure: false,
        dug: false
      });
    }
    castles[Math.floor(Math.random() * castles.length)].hasTreasure = true;
    return { questActive: true, questTimeLeft: 60, sandcastles: castles, messages: [...state.messages.slice(-4), '[系统] 限时寻宝开始！快去挖沙堡！'] };
  }),
  digSandcastle: (id) => set((state) => {
    const sc = state.sandcastles.find(c => c.id === id);
    if (!sc || sc.dug) return state;

    const newCastles = state.sandcastles.map(c => c.id === id ? { ...c, dug: true } : c);

    if (sc.hasTreasure) {
      const specialItem: Item = { id: 'quest_item_' + Date.now(), name: '海神三叉戟', type: 'treasure', value: 5000, icon: '🔱', description: '传说中的海神武器！' };
      setTimeout(() => {
        useGameStore.getState().addMessage(`🌈[全服通报] 恭喜玩家在沙滩岛限时寻宝中获得了传说神器【海神三叉戟】！`);
      }, 100);
      return {
        sandcastles: [],
        questActive: false,
        questTimeLeft: 0,
        inventory: [...state.inventory, specialItem],
        collection: state.collection.includes('海神三叉戟') ? state.collection : [...state.collection, '海神三叉戟']
      };
    }

    return { sandcastles: newCastles };
  }),
  tickQuest: () => set((state) => {
    if (!state.questActive) return state;
    if (state.questTimeLeft <= 1) {
      return { questActive: false, questTimeLeft: 0, sandcastles: [], messages: [...state.messages.slice(-4), '[系统] 寻宝时间到，沙堡消失了！'] };
    }
    return { questTimeLeft: state.questTimeLeft - 1 };
  }),
}),
{
      name: 'island-game-storage',
      partialize: (state) => ({
        money: state.money,
        inventory: state.inventory,
        currentIsland: state.currentIsland,
        detectorOwned: state.detectorOwned,
        boatLevel: state.boatLevel,
        luckLevel: state.luckLevel,
        rodSpeedLevel: state.rodSpeedLevel,
        rodZoneLevel: state.rodZoneLevel,
        unlockedIslands: state.unlockedIslands,
        collection: state.collection,
        currentTaskIndex: state.currentTaskIndex,
        taskProgress: state.taskProgress,
      }),
    }
  )
);
