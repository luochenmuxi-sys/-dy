import React, { useRef, useState, useEffect } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { auth } from './firebase';

const useKeyboard = () => {
  const [keys, setKeys] = useState({ w: false, a: false, s: false, d: false });
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const key = e.key.toLowerCase();
      if (['w', 'a', 's', 'd'].includes(key)) {
        setKeys(k => ({ ...k, [key]: true }));
      }
    };
    const handleKeyUp = (e: KeyboardEvent) => {
      const key = e.key.toLowerCase();
      if (['w', 'a', 's', 'd'].includes(key)) {
        setKeys(k => ({ ...k, [key]: false }));
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);
  return keys;
};
import { OrbitControls, Text, Sphere, Box, Cylinder, Cone, Billboard } from '@react-three/drei';
import * as THREE from 'three';
import { useGameStore } from './store';
import { playSound } from './audio';

const Island = () => {
  const currentIsland = useGameStore(state => state.currentIsland);

  if (currentIsland === 'volcano') {
    return (
      <group>
        {/* Volcano Island Base */}
        <group position={[0, -0.5, 0]}>
          <Cylinder args={[12, 14, 1, 32]} position={[0, 0, 0]}>
            <meshStandardMaterial color="#3f3f3f" roughness={0.9} />
          </Cylinder>
          {/* Push the volcano cone to the back so it doesn't block the view */}
          <Cylinder args={[6, 10, 2, 32]} position={[0, 1.5, -4]}>
            <meshStandardMaterial color="#2a2a2a" roughness={0.9} />
          </Cylinder>
          <Cylinder args={[4, 6, 2, 32]} position={[0, 3.5, -4]}>
            <meshStandardMaterial color="#1a1a1a" roughness={0.9} />
          </Cylinder>
          {/* Lava */}
          <Cylinder args={[3.8, 3.8, 0.1, 32]} position={[0, 4.55, -4]}>
            <meshStandardMaterial color="#ff4500" emissive="#ff4500" emissiveIntensity={2} />
          </Cylinder>
        </group>
        {/* Boiling Water */}
        <Cylinder args={[50, 50, 0.5, 32]} position={[0, -0.8, 0]}>
          <meshStandardMaterial color="#8B0000" transparent opacity={0.8} />
        </Cylinder>
        {/* Dead Trees */}
        {[[-6, -6], [6, -7], [-8, 4], [5, 8]].map((pos, i) => (
          <group key={i} position={[pos[0], 0, pos[1]]} rotation={[Math.random() * 0.5, 0, Math.random() * 0.5]}>
            <Cylinder args={[0.2, 0.3, 3]} position={[0, 1.5, 0]}>
              <meshStandardMaterial color="#1a1a1a" />
            </Cylinder>
            <Cylinder args={[0.05, 0.1, 1.5]} position={[0.5, 2, 0]} rotation={[0, 0, Math.PI/4]}>
              <meshStandardMaterial color="#1a1a1a" />
            </Cylinder>
          </group>
        ))}
        {/* Boat */}
        <group position={[14, 0, 5]} rotation={[0, -Math.PI/4, 0]}>
          <Box args={[3, 1, 1.5]} position={[0, 0.5, 0]}>
            <meshStandardMaterial color="#A16207" />
          </Box>
          <Cylinder args={[0.1, 0.1, 3]} position={[0, 2, 0]}>
            <meshStandardMaterial color="#ffffff" />
          </Cylinder>
          <Box args={[0.1, 2, 1.5]} position={[0, 2, 0.75]}>
            <meshStandardMaterial color="#ffffff" />
          </Box>
        </group>
      </group>
    );
  }

  if (currentIsland === 'forest') {
    return (
      <group>
        {/* Forest Island Base */}
        <group position={[0, -0.5, 0]}>
          <Cylinder args={[10, 11, 1, 32]} position={[0, 0, 0]}>
            <meshStandardMaterial color="#2E8B57" roughness={0.9} />
          </Cylinder>
          <Cylinder args={[6, 7, 1, 32]} position={[6, 0, 5]}>
            <meshStandardMaterial color="#2E8B57" roughness={0.9} />
          </Cylinder>
          <Cylinder args={[7, 8, 1, 32]} position={[-5, 0, 6]}>
            <meshStandardMaterial color="#2E8B57" roughness={0.9} />
          </Cylinder>
        </group>
        {/* Dark Water */}
        <Cylinder args={[50, 50, 0.5, 32]} position={[0, -0.8, 0]}>
          <meshStandardMaterial color="#0F4C5C" transparent opacity={0.9} />
        </Cylinder>
        {/* Pine Trees */}
        {[[-3, -4], [4, -5], [-6, 2], [2, 6], [7, 0]].map((pos, i) => (
          <group key={i} position={[pos[0], 0, pos[1]]}>
            <Cylinder args={[0.3, 0.4, 2]} position={[0, 1, 0]}>
              <meshStandardMaterial color="#3E2723" />
            </Cylinder>
            <Cone args={[2, 4, 8]} position={[0, 3, 0]}>
              <meshStandardMaterial color="#1B5E20" />
            </Cone>
            <Cone args={[1.5, 3, 8]} position={[0, 4.5, 0]}>
              <meshStandardMaterial color="#1B5E20" />
            </Cone>
          </group>
        ))}
        {/* Boat */}
        <group position={[12, 0, 5]} rotation={[0, -Math.PI/4, 0]}>
          <Box args={[3, 1, 1.5]} position={[0, 0.5, 0]}>
            <meshStandardMaterial color="#A16207" />
          </Box>
          <Cylinder args={[0.1, 0.1, 3]} position={[0, 2, 0]}>
            <meshStandardMaterial color="#ffffff" />
          </Cylinder>
          <Box args={[0.1, 2, 1.5]} position={[0, 2, 0.75]}>
            <meshStandardMaterial color="#ffffff" />
          </Box>
        </group>
      </group>
    );
  }

  // Default Sand Island
  return (
    <group>
      {/* Irregular Sand Island */}
      <group position={[0, -0.5, 0]}>
        <Cylinder args={[8, 9, 1, 32]} position={[0, 0, 0]}>
          <meshStandardMaterial color="#FDE047" roughness={0.8} />
        </Cylinder>
        <Cylinder args={[5, 6, 1, 32]} position={[5, 0, 4]}>
          <meshStandardMaterial color="#FDE047" roughness={0.8} />
        </Cylinder>
        <Cylinder args={[6, 7, 1, 32]} position={[-4, 0, 5]}>
          <meshStandardMaterial color="#FDE047" roughness={0.8} />
        </Cylinder>
        <Cylinder args={[4, 5, 1, 32]} position={[6, 0, -4]}>
          <meshStandardMaterial color="#FDE047" roughness={0.8} />
        </Cylinder>
        <Cylinder args={[5, 6, 1, 32]} position={[-5, 0, -5]}>
          <meshStandardMaterial color="#FDE047" roughness={0.8} />
        </Cylinder>
      </group>
      {/* Blue Water */}
      <Cylinder args={[50, 50, 0.5, 32]} position={[0, -0.8, 0]}>
        <meshStandardMaterial color="#3B82F6" transparent opacity={0.8} />
      </Cylinder>
      {/* Palm Tree */}
      <group position={[-5, 0, -5]}>
        <Cylinder args={[0.2, 0.3, 3]} position={[0, 1.5, 0]}>
          <meshStandardMaterial color="#8B4513" />
        </Cylinder>
        <Cone args={[1.5, 2, 5]} position={[0, 3, 0]}>
          <meshStandardMaterial color="#22C55E" />
        </Cone>
      </group>
      {/* Boat */}
      <group position={[12, 0, 5]} rotation={[0, -Math.PI/4, 0]}>
        <Box args={[3, 1, 1.5]} position={[0, 0.5, 0]}>
          <meshStandardMaterial color="#A16207" />
        </Box>
        <Cylinder args={[0.1, 0.1, 3]} position={[0, 2, 0]}>
          <meshStandardMaterial color="#ffffff" />
        </Cylinder>
        <Box args={[0.1, 2, 1.5]} position={[0, 2, 0.75]}>
          <meshStandardMaterial color="#ffffff" />
        </Box>
      </group>
    </group>
  );
};

const GoldenChest = () => {
  const isNearChest = useGameStore(state => state.isNearChest);
  const questActive = useGameStore(state => state.questActive);
  const startQuest = useGameStore(state => state.startQuest);
  const currentIsland = useGameStore(state => state.currentIsland);

  if (currentIsland !== 'sand') return null;

  return (
    <group position={[0, 0.5, -4]} onClick={(e) => { e.stopPropagation(); if (isNearChest && !questActive) startQuest(); }}>
      <Box args={[1.2, 1, 0.8]}>
        <meshStandardMaterial color="#FFD700" emissive="#FFD700" emissiveIntensity={isNearChest ? 0.8 : 0.1} metalness={0.8} roughness={0.2} />
      </Box>
      <Cylinder args={[0.6, 0.6, 1.2, 16, 1, false, 0, Math.PI]} position={[0, 0.5, 0]} rotation={[0, 0, Math.PI / 2]}>
        <meshStandardMaterial color="#DAA520" emissive="#DAA520" emissiveIntensity={isNearChest ? 0.8 : 0.1} metalness={0.8} roughness={0.2} />
      </Cylinder>
      {isNearChest && !questActive && (
        <Billboard position={[0, 2, 0]}>
          <Text fontSize={0.4} color="white" outlineWidth={0.05} outlineColor="black">点击开启限时寻宝</Text>
        </Billboard>
      )}
    </group>
  );
};

const Sandcastles = () => {
  const sandcastles = useGameStore(state => state.sandcastles);
  const digSandcastle = useGameStore(state => state.digSandcastle);
  const currentIsland = useGameStore(state => state.currentIsland);
  const playerState = useGameStore(state => state.playerState);

  if (currentIsland !== 'sand') return null;

  return (
    <>
      {sandcastles.map(sc => !sc.dug && (
        <group key={sc.id} position={[sc.x, 0.4, sc.z]} onClick={(e) => {
          e.stopPropagation();
          if (playerState === 'idle') {
            if (sc.hasTreasure) playSound('coin');
            else playSound('boing');
            digSandcastle(sc.id);
          }
        }}>
          <Cone args={[0.6, 1.2, 4]} position={[0, 0, 0]}>
            <meshStandardMaterial color="#E6C280" roughness={1} />
          </Cone>
          <Billboard position={[0, 1, 0]}>
            <Text fontSize={0.3} color="white" outlineWidth={0.05} outlineColor="black">挖开</Text>
          </Billboard>
        </group>
      ))}
    </>
  );
};

const Player = () => {
  const playerState = useGameStore(state => state.playerState);
  const showingItem = useGameStore(state => state.showingItem);
  const currentEmote = useGameStore(state => state.currentEmote);
  const groupRef = useRef<THREE.Group>(null);
  const [headScale, setHeadScale] = useState(1);
  const keys = useKeyboard();
  const speed = 6;
  const lastWalkSoundRef = useRef(0);
  const chestPos = new THREE.Vector3(0, 0.5, -4);

  useFrame((state, delta) => {
    if (groupRef.current) {
      // 2.5D Camera Follow Logic
      const targetCameraPos = new THREE.Vector3(
        groupRef.current.position.x,
        12, // Fixed height
        groupRef.current.position.z + 15 // Fixed offset for 2.5D feel
      );
      state.camera.position.lerp(targetCameraPos, 0.1);
      state.camera.lookAt(groupRef.current.position.x, 0, groupRef.current.position.z);

      if (playerState === 'idle') {
        // Check distance to chest
        const dist = groupRef.current.position.distanceTo(chestPos);
        const near = dist < 3;
        if (near !== useGameStore.getState().isNearChest) {
          useGameStore.getState().setIsNearChest(near);
        }

        let dx = 0;
        let dz = 0;
        if (keys.w) dz -= 1;
        if (keys.s) dz += 1;
        if (keys.a) dx -= 1;
        if (keys.d) dx += 1;

        if (dx !== 0 || dz !== 0) {
          const length = Math.sqrt(dx * dx + dz * dz);
          dx /= length;
          dz /= length;
          
          const newX = groupRef.current.position.x + dx * speed * delta;
          const newZ = groupRef.current.position.z + dz * speed * delta;
          
          // Simple boundary check (radius ~9.5)
          if (Math.sqrt(newX * newX + newZ * newZ) < 9.5) {
            groupRef.current.position.x = newX;
            groupRef.current.position.z = newZ;
          }
          
          groupRef.current.rotation.y = Math.atan2(dx, dz);
          groupRef.current.rotation.z = Math.sin(state.clock.elapsedTime * 15) * 0.1; // Walk wobble
          
          // Play walk sound every 0.25 seconds
          if (state.clock.elapsedTime - lastWalkSoundRef.current > 0.25) {
            playSound('walk');
            lastWalkSoundRef.current = state.clock.elapsedTime;
          }
        } else {
          groupRef.current.rotation.z = 0;
        }
        groupRef.current.position.y = 1;
        setHeadScale(1);
      } else if (playerState === 'fishing') {
        // Bobbing head while fishing (light up and down)
        groupRef.current.position.y = 1 + Math.sin(state.clock.elapsedTime * 2) * 0.05;
        setHeadScale(1);
      } else if (playerState === 'fish_biting') {
        // Shaking head more noticeably
        groupRef.current.position.y = 1 + Math.sin(state.clock.elapsedTime * 20) * 0.1;
        groupRef.current.rotation.z = Math.sin(state.clock.elapsedTime * 30) * 0.1;
        setHeadScale(1.1);
      } else if (playerState === 'digging' || playerState === 'building' || playerState === 'mining') {
        // Shaking while digging/building/mining
        groupRef.current.rotation.z = Math.sin(state.clock.elapsedTime * 20) * 0.1;
        groupRef.current.position.y = 1;
      } else if (playerState === 'shaking') {
        // Shaking side to side
        groupRef.current.position.x += Math.sin(state.clock.elapsedTime * 30) * 0.05;
        groupRef.current.position.y = 1;
      } else if (playerState === 'trapped') {
        // Frantic shaking and half buried
        groupRef.current.rotation.z = Math.sin(state.clock.elapsedTime * 30) * 0.3;
        groupRef.current.position.y = 0.2; // Buried in sand
        setHeadScale(1.5); // Big head when trapped
      }

      // Expose position for multiplayer sync
      (window as any).currentPlayerPosition = {
        x: groupRef.current.position.x,
        z: groupRef.current.position.z,
        rotationY: groupRef.current.rotation.y
      };
    }
  });

  return (
    <group ref={groupRef} position={[0, 1, 0]}>
      {/* Big Head */}
      <Sphere args={[0.5, 16, 16]} position={[0, 1, 0]} scale={headScale}>
        <meshStandardMaterial color="#ffffff" />
      </Sphere>
      {/* Face (derpy) */}
      <Text position={[0, 1, 0.51]} fontSize={0.3} color="black">
        {playerState === 'trapped' ? 'X_X' : playerState === 'fish_biting' ? 'O_O' : playerState === 'fishing' ? 'O_o' : '._.'}
      </Text>
      {/* Stick Body */}
      <Cylinder args={[0.1, 0.1, 1]} position={[0, 0, 0]}>
        <meshStandardMaterial color="#000000" />
      </Cylinder>
      {/* Fishing Rod (conditionally rendered) */}
      {(playerState === 'fishing' || playerState === 'fish_biting') && (
        <group position={[0.5, 0.5, 0]} rotation={[0, 0, playerState === 'fish_biting' ? -Math.PI / 3 : -Math.PI / 4]}>
          <Cylinder args={[0.05, 0.05, 2]} position={[0, 1, 0]}>
            <meshStandardMaterial color="#8B4513" />
          </Cylinder>
          <Cylinder args={[0.01, 0.01, 2]} position={[0, 2, 1]} rotation={[Math.PI/2, 0, 0]}>
            <meshStandardMaterial color="#ffffff" />
          </Cylinder>
        </group>
      )}
      {/* Shovel (conditionally rendered) */}
      {(playerState === 'digging' || playerState === 'building' || playerState === 'mining') && (
        <group position={[0.5, 0.5, 0]} rotation={[0, 0, Math.PI / 4]}>
          <Cylinder args={[0.05, 0.05, 1.5]} position={[0, 0.75, 0]}>
            <meshStandardMaterial color="#8B4513" />
          </Cylinder>
          {playerState === 'mining' ? (
            <Box args={[0.4, 0.1, 0.1]} position={[0, 1.5, 0]}>
              <meshStandardMaterial color="#9CA3AF" />
            </Box>
          ) : (
            <Box args={[0.3, 0.4, 0.05]} position={[0, 1.6, 0]}>
              <meshStandardMaterial color="#9CA3AF" />
            </Box>
          )}
        </group>
      )}
      
      {/* Showing Item */}
      {showingItem && playerState === 'idle' && (
        <Billboard position={[0, 2.2, 0]}>
          <Text fontSize={0.8}>{showingItem.icon}</Text>
        </Billboard>
      )}

      {/* Emote Bubble */}
      {currentEmote && (
        <Billboard position={[0, showingItem && playerState === 'idle' ? 3.2 : 2.5, 0]}>
          <Box args={[1.2, 1.2, 0.1]} position={[0, 0, -0.05]}>
            <meshStandardMaterial color="white" />
          </Box>
          <Text fontSize={0.8} color="black" position={[0, 0, 0]}>{currentEmote}</Text>
        </Billboard>
      )}

      {/* Local Player Chat Bubble */}
      {auth.currentUser && (
        <PlayerChatBubble uid={auth.currentUser.uid} position={[0, showingItem && playerState === 'idle' ? 4.2 : 3.5, 0]} />
      )}
    </group>
  );
};

const PlayerChatBubble = ({ uid, position }: { uid: string, position: [number, number, number] }) => {
  const chatMessages = useGameStore(state => state.chatMessages);
  const [activeMessage, setActiveMessage] = useState<string | null>(null);

  useEffect(() => {
    // Find the latest message for this player
    const playerMessages = chatMessages.filter(m => m.uid === uid);
    if (playerMessages.length > 0) {
      const latestMsg = playerMessages[playerMessages.length - 1];
      // Check if it's recent (within last 5 seconds)
      const now = Date.now();
      const msgTime = latestMsg.timestamp?.toMillis ? latestMsg.timestamp.toMillis() : now;
      if (now - msgTime < 5000) {
        setActiveMessage(latestMsg.text);
        const timer = setTimeout(() => setActiveMessage(null), 5000 - (now - msgTime));
        return () => clearTimeout(timer);
      }
    }
  }, [chatMessages, uid]);

  if (!activeMessage) return null;

  return (
    <Billboard position={position}>
      <Box args={[Math.max(2, activeMessage.length * 0.3), 0.8, 0.1]} position={[0, 0, -0.05]}>
        <meshStandardMaterial color="white" />
      </Box>
      <Text fontSize={0.3} color="black" position={[0, 0, 0]} maxWidth={3} textAlign="center">
        {activeMessage}
      </Text>
    </Billboard>
  );
};

const OtherPlayers = () => {
  const otherPlayers = useGameStore(state => state.otherPlayers);

  return (
    <>
      {otherPlayers.map(player => (
        <group key={player.uid} position={[player.x, 1, player.z]} rotation={[0, player.rotationY, 0]}>
          {/* Big Head */}
          <Sphere args={[0.5, 16, 16]} position={[0, 1, 0]} scale={player.state === 'trapped' ? 1.5 : player.state === 'fish_biting' ? 1.1 : 1}>
            <meshStandardMaterial color="#cccccc" />
          </Sphere>
          {/* Face (derpy) */}
          <Text position={[0, 1, 0.51]} fontSize={0.3} color="black">
            {player.state === 'trapped' ? 'X_X' : player.state === 'fish_biting' ? 'O_O' : player.state === 'fishing' ? 'O_o' : '._.'}
          </Text>
          {/* Stick Body */}
          <Cylinder args={[0.1, 0.1, 1]} position={[0, 0, 0]}>
            <meshStandardMaterial color="#333333" />
          </Cylinder>
          
          {/* Name Tag */}
          <Billboard position={[0, 2.2, 0]}>
            <Text fontSize={0.3} color="white" outlineWidth={0.05} outlineColor="black">
              {player.displayName}
            </Text>
          </Billboard>

          {/* Chat Bubble */}
          <PlayerChatBubble uid={player.uid} position={[0, 3.5, 0]} />

          {/* Emote Bubble */}
          {player.emote && (
            <Billboard position={[0, 2.8, 0]}>
              <Box args={[1.2, 1.2, 0.1]} position={[0, 0, -0.05]}>
                <meshStandardMaterial color="white" />
              </Box>
              <Text fontSize={0.8} color="black" position={[0, 0, 0]}>{player.emote}</Text>
            </Billboard>
          )}

          {/* Fishing Rod (conditionally rendered) */}
          {(player.state === 'fishing' || player.state === 'fish_biting') && (
            <group position={[0.5, 0.5, 0]} rotation={[0, 0, player.state === 'fish_biting' ? -Math.PI / 3 : -Math.PI / 4]}>
              <Cylinder args={[0.05, 0.05, 2]} position={[0, 1, 0]}>
                <meshStandardMaterial color="#8B4513" />
              </Cylinder>
              <Cylinder args={[0.01, 0.01, 2]} position={[0, 2, 1]} rotation={[Math.PI/2, 0, 0]}>
                <meshStandardMaterial color="#ffffff" />
              </Cylinder>
            </group>
          )}
          {/* Shovel (conditionally rendered) */}
          {(player.state === 'digging' || player.state === 'building' || player.state === 'mining') && (
            <group position={[0.5, 0.5, 0]} rotation={[0, 0, Math.PI / 4]}>
              <Cylinder args={[0.05, 0.05, 1.5]} position={[0, 0.75, 0]}>
                <meshStandardMaterial color="#8B4513" />
              </Cylinder>
              {player.state === 'mining' ? (
                <Box args={[0.4, 0.1, 0.1]} position={[0, 1.5, 0]}>
                  <meshStandardMaterial color="#9CA3AF" />
                </Box>
              ) : (
                <Box args={[0.3, 0.4, 0.05]} position={[0, 1.6, 0]}>
                  <meshStandardMaterial color="#9CA3AF" />
                </Box>
              )}
            </group>
          )}
        </group>
      ))}
    </>
  );
};

export const GameScene = () => {
  const isSailing = useGameStore(state => state.isSailing);

  return (
    <Canvas camera={{ position: [0, 12, 15], fov: 50 }}>
      <ambientLight intensity={0.5} />
      <directionalLight position={[10, 10, 5]} intensity={1} castShadow />
      {!isSailing && (
        <>
          <GoldenChest />
          <Sandcastles />
          <Island />
          <Player />
          <OtherPlayers />
        </>
      )}
      {/* Removed OrbitControls to allow manual 2.5D camera follow */}
    </Canvas>
  );
};

