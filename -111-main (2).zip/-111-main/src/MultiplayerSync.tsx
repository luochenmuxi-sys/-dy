import { useEffect, useRef } from 'react';
import { useGameStore } from './store';
import { auth, db, loginAnonymously, handleFirestoreError, OperationType } from './firebase';
import { onAuthStateChanged } from 'firebase/auth';
import { collection, doc, onSnapshot, setDoc, serverTimestamp, query, where, limit, orderBy } from 'firebase/firestore';

export function MultiplayerSync() {
  const { 
    currentIsland, 
    playerState, 
    currentEmote, 
    setOtherPlayers, 
    setChatMessages 
  } = useGameStore();

  // We need to track the player's position from the 3D scene.
  // Since the position is managed by React Three Fiber in Scene.tsx,
  // we'll expose a global way to get it or just sync it from Scene.tsx.
  // For simplicity, we'll let Scene.tsx update a ref on window, and read it here.
  
  useEffect(() => {
    let unsubscribeAuth: () => void;
    let unsubscribePlayers: () => void;
    let unsubscribeChat: () => void;
    let syncInterval: NodeJS.Timeout;

    const init = async () => {
      unsubscribeAuth = onAuthStateChanged(auth, (user) => {
        if (user) {
          // Listen to other players on the same island
          const playersQuery = query(
            collection(db, 'players'),
            where('island', '==', currentIsland)
          );

          unsubscribePlayers = onSnapshot(playersQuery, (snapshot) => {
            const now = Date.now();
            const players = snapshot.docs
              .map(doc => doc.data() as any)
              .filter(p => p.uid !== user.uid)
              // Filter out players inactive for more than 30 seconds
              .filter(p => p.lastActive && (now - p.lastActive.toMillis()) < 30000);
            
            setOtherPlayers(players);
          }, (error) => handleFirestoreError(error, OperationType.GET, 'players'));

          // Listen to chat messages on the same island
          const chatQuery = query(
            collection(db, 'chat'),
            where('island', '==', currentIsland),
            orderBy('timestamp', 'desc'),
            limit(10)
          );

          unsubscribeChat = onSnapshot(chatQuery, (snapshot) => {
            const messages = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as any)).reverse();
            setChatMessages(messages);
          }, (error) => handleFirestoreError(error, OperationType.GET, 'chat'));

          // Sync loop
          syncInterval = setInterval(async () => {
            const pos = (window as any).currentPlayerPosition || { x: 0, z: 0, rotationY: 0 };
            try {
              await setDoc(doc(db, 'players', user.uid), {
                uid: user.uid,
                displayName: user.displayName || '匿名玩家',
                photoURL: user.photoURL || '',
                island: useGameStore.getState().currentIsland,
                x: pos.x,
                z: pos.z,
                rotationY: pos.rotationY,
                state: useGameStore.getState().playerState,
                emote: useGameStore.getState().currentEmote || null,
                lastActive: serverTimestamp()
              }, { merge: true });
            } catch (error) {
              // Silently fail sync to avoid spamming errors if offline
            }
          }, 1000); // Sync every 1 second
        } else {
          loginAnonymously();
        }
      });
    };

    init();

    return () => {
      if (unsubscribeAuth) unsubscribeAuth();
      if (unsubscribePlayers) unsubscribePlayers();
      if (unsubscribeChat) unsubscribeChat();
      if (syncInterval) clearInterval(syncInterval);
    };
  }, [currentIsland]); // Re-subscribe when island changes

  return null;
}
