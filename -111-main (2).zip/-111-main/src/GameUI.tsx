import React, { useState, useEffect } from 'react';
import { useGameStore, Item, TASKS } from './store';
import { Fish, Pickaxe, Store, Ship, X, AlertTriangle, Book, Smile, CheckCircle, Castle, TreePine, Gem, Share2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { playSound } from './audio';

const FISH_TYPES = [
  { name: '长牙金鱼', type: 'fish', value: 10, icon: '🐟', description: '长着人类牙齿的金鱼，有点der' },
  { name: '破旧内裤', type: 'trash', value: 1, icon: '🩲', description: '不知道谁丢在海里的' },
  { name: '海神三叉戟', type: 'treasure', value: 100, icon: '🔱', description: '闪闪发光的稀有宝物！' },
  { name: '鮟鱇鱼', type: 'fish', value: 20, icon: '🐡', description: '点击会哈气，丑萌丑萌的' },
  { name: '美人鱼的假发', type: 'treasure', value: 500, icon: '🧜‍♀️', description: '传说中美人鱼掉落的假发，极其罕见！' },
];

const DIG_TYPES = [
  { name: '金币', type: 'treasure', value: 5, icon: '🪙', description: '一枚古老的金币' },
  { name: '沙子', type: 'trash', value: 0, icon: '🏖️', description: '就只是一把沙子' },
  { name: '神秘化石', type: 'treasure', value: 50, icon: '🦴', description: '看起来很值钱的骨头' },
  { name: '外星人的诺基亚', type: 'treasure', value: 999, icon: '📱', description: '还能开机！里面还有贪吃蛇！' },
];

const FOREST_FISH_TYPES = [
  { name: '枯叶鱼', type: 'fish', value: 15, icon: '🍂', description: '长得像落叶的鱼，擅长伪装' },
  { name: '毒蘑菇', type: 'trash', value: 2, icon: '🍄', description: '吃了会看到小人跳舞' },
  { name: '食人鱼', type: 'fish', value: 30, icon: '🐟', description: '牙齿非常锋利，小心手指！' },
  { name: '远古巨鳄', type: 'treasure', value: 300, icon: '🐊', description: '这也能钓上来？！' },
  { name: '精灵的竖琴', type: 'treasure', value: 800, icon: '🪕', description: '弹奏时会吸引小动物' },
];

const FOREST_DIG_TYPES = [
  { name: '树根', type: 'trash', value: 1, icon: '🪵', description: '一段普通的树根' },
  { name: '闪光甲虫', type: 'treasure', value: 40, icon: '🪲', description: '活的！还在发光！' },
  { name: '古代石板', type: 'treasure', value: 150, icon: '🪨', description: '上面刻着看不懂的文字' },
  { name: '恐龙蛋化石', type: 'treasure', value: 1200, icon: '🥚', description: '极其珍贵的史前遗物！' },
];

const VOLCANO_FISH_TYPES = [
  { name: '烤熟的鱼', type: 'fish', value: 20, icon: '🍣', description: '刚钓上来就已经熟了' },
  { name: '黑炭', type: 'trash', value: 5, icon: '🪨', description: '烫手！' },
  { name: '熔岩章鱼', type: 'fish', value: 80, icon: '🐙', description: '触手还在喷火' },
  { name: '火龙鳞片', type: 'treasure', value: 500, icon: '🔥', description: '传说中火龙的鳞片' },
  { name: '凤凰羽毛', type: 'treasure', value: 2000, icon: '🪶', description: '永不熄灭的羽毛' },
];

const VOLCANO_DIG_TYPES = [
  { name: '火山灰', type: 'trash', value: 2, icon: '🌪️', description: '呛人的灰尘' },
  { name: '黑曜石', type: 'treasure', value: 80, icon: '💎', description: '非常坚硬的黑色石头' },
  { name: '红宝石', type: 'treasure', value: 300, icon: '♦️', description: '闪耀着血红色的光芒' },
  { name: '恶魔角', type: 'treasure', value: 3000, icon: '😈', description: '散发着邪恶的气息' },
];

const ISLANDS = [
  { id: 'sand', name: '沙滩岛', icon: '🏖️', cost: 0, x: 20, y: 50, level: 1 },
  { id: 'forest', name: '迷雾森林岛', icon: '🌲', cost: 500, x: 50, y: 30, level: 2 },
  { id: 'volcano', name: '烈焰火山岛', icon: '🌋', cost: 2000, x: 80, y: 60, level: 3 },
];

const ALL_ITEMS = [
  ...FISH_TYPES, ...DIG_TYPES,
  ...FOREST_FISH_TYPES, ...FOREST_DIG_TYPES,
  ...VOLCANO_FISH_TYPES, ...VOLCANO_DIG_TYPES
];

const EMOTES = ['😀', '😂', '😭', '😡', '❤️', '💩', '👍', '👎', '🐟', '💰'];

export const GameUI = () => {
  const { 
    money, inventory, currentIsland, detectorOwned, boatLevel, luckLevel, rodSpeedLevel, rodZoneLevel, unlockedIslands, isSailing, collection, showingItem, currentEmote,
    questActive, questTimeLeft, tickQuest, currentTaskIndex, taskProgress, updateTask, claimTaskReward,
    playerState, setPlayerState, addMoney, addItem, removeItem, buyDetector, buyLuckUpgrade, buyRodSpeedUpgrade, buyRodZoneUpgrade, sellAll, setIsland, unlockIsland, setSailing, addMessage, messages, setShowingItem, setEmote 
  } = useGameStore();

  const [showShop, setShowShop] = useState(false);
  const [shopTab, setShopTab] = useState<'buy' | 'sell'>('buy');
  const [showInventory, setShowInventory] = useState(false);
  const [showBoat, setShowBoat] = useState(false);
  const [showCollection, setShowCollection] = useState(false);
  const [showEmotes, setShowEmotes] = useState(false);
  const [actionResult, setActionResult] = useState<Item | null>(null);
  const [adState, setAdState] = useState<{ playing: boolean, timeLeft: number, reward: (() => void) | null }>({ playing: false, timeLeft: 0, reward: null });
  const [fishingGame, setFishingGame] = useState<{
    active: boolean;
    item: Item | null;
    zoneSize: number;
    sliderPos: number;
    direction: number;
  } | null>(null);

  useEffect(() => {
    if (adState.playing && adState.timeLeft > 0) {
      const timer = setTimeout(() => {
        setAdState(prev => ({ ...prev, timeLeft: prev.timeLeft - 1 }));
      }, 1000);
      return () => clearTimeout(timer);
    }
  }, [adState]);

  const [chatInput, setChatInput] = useState('');
  const chatMessages = useGameStore(state => state.chatMessages);
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    const initAuth = async () => {
      const { auth } = await import('./firebase');
      const { onAuthStateChanged } = await import('firebase/auth');
      onAuthStateChanged(auth, (u) => {
        setUser(u);
      });
    };
    initAuth();
  }, []);

  const handleLogin = async () => {
    const { loginWithGoogle } = await import('./firebase');
    await loginWithGoogle();
  };

  const handleSendChat = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;
    
    const { auth, db } = await import('./firebase');
    const { collection, addDoc, serverTimestamp } = await import('firebase/firestore');
    
    if (auth.currentUser) {
      try {
        await addDoc(collection(db, 'chat'), {
          uid: auth.currentUser.uid,
          displayName: auth.currentUser.displayName || '匿名玩家',
          text: chatInput.trim(),
          timestamp: serverTimestamp(),
          island: currentIsland
        });
        setChatInput('');
      } catch (error) {
        console.error("Error sending chat:", error);
      }
    }
  };

  const handleEmote = (emote: string) => {
    setEmote(emote);
    setShowEmotes(false);
    playSound('boing');
    
    // Clear emote after 3 seconds
    setTimeout(() => {
      // Only clear if it hasn't been overwritten
      setEmote(null);
    }, 3000);
  };

  useEffect(() => {
    const interval = setInterval(() => {
      tickQuest();
    }, 1000);
    return () => clearInterval(interval);
  }, [tickQuest]);

  // Mock multiplayer broadcasts
  useEffect(() => {
    const interval = setInterval(() => {
      if (Math.random() > 0.7) {
        addMessage(`[全岛广播] 玩家"大聪明"挖到了一个破旧内裤！`);
      }
    }, 15000);
    return () => clearInterval(interval);
  }, [addMessage]);

  useEffect(() => {
    let animationFrameId: number;
    if (fishingGame?.active) {
      const speed = Math.max(0.3, 1.0 - rodSpeedLevel * 0.12); // Base speed 1.0, decreases with upgrades
      const updateSlider = () => {
        setFishingGame(prev => {
          if (!prev) return prev;
          let newPos = prev.sliderPos + prev.direction * speed;
          let newDir = prev.direction;
          if (newPos >= 100) {
            newPos = 100;
            newDir = -1;
          } else if (newPos <= 0) {
            newPos = 0;
            newDir = 1;
          }
          return { ...prev, sliderPos: newPos, direction: newDir };
        });
        animationFrameId = requestAnimationFrame(updateSlider);
      };
      animationFrameId = requestAnimationFrame(updateSlider);
    }
    return () => cancelAnimationFrame(animationFrameId);
  }, [fishingGame?.active]);

  const handleFish = () => {
    if (playerState !== 'idle') return;
    setPlayerState('fishing');
    playSound('splash');
    
    // Simulate vibration
    if (navigator.vibrate) navigator.vibrate([100, 50, 100]);

    setTimeout(() => {
      // Bite!
      if (navigator.vibrate) navigator.vibrate([300, 100, 300, 100, 500]);
      playSound('bite');
      
      const rand = Math.random();
      const luckBonus = luckLevel * 0.02; // +2% rare chance per luck level
      const currentFishPool = currentIsland === 'sand' ? FISH_TYPES : currentIsland === 'forest' ? FOREST_FISH_TYPES : VOLCANO_FISH_TYPES;
      
      let caughtItem;
      if (rand < 0.05 + luckBonus) caughtItem = currentFishPool[4]; // 5% super rare
      else if (rand < 0.2 + luckBonus * 2) caughtItem = currentFishPool[2]; // 15% rare
      else if (rand < 0.5 - luckBonus) caughtItem = currentFishPool[1]; // 30% trash
      else caughtItem = currentFishPool[Math.random() > 0.5 ? 0 : 3]; // 50% normal fish

      let baseZoneSize = 40; // Default easy
      if (caughtItem.type === 'treasure') baseZoneSize = 10;
      else if (caughtItem.value > 100) baseZoneSize = 15;
      else if (caughtItem.value > 50) baseZoneSize = 25;
      else if (caughtItem.type === 'trash') baseZoneSize = 50;

      const zoneSize = Math.min(100, baseZoneSize + rodZoneLevel * 5); // Increase zone size with upgrades

      setPlayerState('fish_biting');
      setFishingGame({
        active: true,
        item: caughtItem as Item,
        zoneSize,
        sliderPos: 0,
        direction: 1
      });
    }, 3000);
  };

  const handleCatchFish = () => {
    if (!fishingGame || !fishingGame.active) return;
    
    const center = 50;
    const halfZone = fishingGame.zoneSize / 2;
    const minSuccess = center - halfZone;
    const maxSuccess = center + halfZone;

    if (fishingGame.sliderPos >= minSuccess && fishingGame.sliderPos <= maxSuccess) {
      // Success!
      const item: Item = { ...fishingGame.item, id: Math.random().toString(36).substring(7) } as Item;
      addItem(item);
      setActionResult(item);
      updateTask('fish', 1);
      playSound('tada');
      if (item.type === 'treasure') {
        addMessage(`[全岛广播] 你钓到了稀有宝贝：${item.name}！快去显摆吧！`);
      } else if (item.type === 'trash') {
        addMessage(`[嘲讽] 你钓到了垃圾：${item.name}，真倒霉！`);
      }
    } else {
      // Fail
      playSound('error');
      addMessage(`[提示] 哎呀，鱼跑了！`);
    }
    
    setFishingGame(null);
    setPlayerState('idle');
  };

  const handleDig = () => {
    if (playerState !== 'idle') return;
    setPlayerState('digging');
    
    if (detectorOwned) {
      // Beep beep beep
      let beeps = 0;
      const beepInterval = setInterval(() => {
        playSound('beep');
        beeps++;
        if (beeps >= 3) clearInterval(beepInterval);
      }, 500);
    }

    setTimeout(() => {
      const rand = Math.random();
      
      // 10% chance to get trapped (cave-in)
      if (rand < 0.1) {
        setPlayerState('trapped');
        playSound('boing');
        addMessage(`[警告] 挖塌了！你被沙子埋起来了！等待队友救援...`);
        // Auto rescue after 5s for single player prototype
        setTimeout(() => {
          setPlayerState('idle');
          addMessage(`[系统] 好心路人把你挖出来了。`);
        }, 5000);
        return;
      }

      let dugItem;
      const itemRand = Math.random(); // Use new random for item to avoid trap bias
      const luckBonus = luckLevel * 0.02; // +2% rare chance per luck level
      const currentDigPool = currentIsland === 'sand' ? DIG_TYPES : currentIsland === 'forest' ? FOREST_DIG_TYPES : VOLCANO_DIG_TYPES;
      
      if (!detectorOwned) {
        dugItem = currentDigPool[1]; // 100% trash/sand
        addMessage(`[提示] 徒手挖什么也挖不到，去商店买个探测器吧！`);
      } else {
        if (itemRand < 0.05 + luckBonus) dugItem = currentDigPool[3]; // 5% super rare
        else if (itemRand < 0.4 + luckBonus * 2) dugItem = currentDigPool[2]; // 35% rare
        else if (itemRand < 0.7) dugItem = currentDigPool[0]; // 30% normal
        else dugItem = currentDigPool[1]; // 30% trash
      }

      if (dugItem.type === 'treasure') playSound('coin');

      updateTask('dig', 1);

      const item: Item = { ...dugItem, id: Math.random().toString(36).substring(7) } as Item;
      addItem(item);
      setActionResult(item);
      setPlayerState('idle');
    }, 2000);
  };

  const handleSpecialAction = () => {
    if (playerState !== 'idle') return;
    
    if (currentIsland === 'sand') {
      setPlayerState('building');
      playSound('splash');
      setTimeout(() => {
        setPlayerState('idle');
        addMessage(`[系统] 你堆了一个漂亮的沙堡！`);
        // 10% chance to find something while building
        if (Math.random() < 0.1) {
          const item = { ...DIG_TYPES[Math.floor(Math.random() * DIG_TYPES.length)], id: Math.random().toString(36).substring(7) } as Item;
          addItem(item);
          setActionResult(item);
          playSound('coin');
        }
      }, 2000);
    } else if (currentIsland === 'forest') {
      setPlayerState('shaking');
      playSound('boing');
      setTimeout(() => {
        setPlayerState('idle');
        const rand = Math.random();
        if (rand < 0.2) {
          addMessage(`[警告] 哎呀！你摇下了一个马蜂窝！被蛰了！`);
          playSound('error');
          // Lose some money or just get stunned
        } else if (rand < 0.5) {
          const item = { ...FOREST_DIG_TYPES[Math.floor(Math.random() * FOREST_DIG_TYPES.length)], id: Math.random().toString(36).substring(7) } as Item;
          addItem(item);
          setActionResult(item);
          playSound('coin');
        } else {
          addMessage(`[系统] 树叶沙沙作响，但什么也没掉下来。`);
        }
      }, 2000);
    } else if (currentIsland === 'volcano') {
      setPlayerState('mining');
      playSound('beep');
      setTimeout(() => {
        setPlayerState('idle');
        const rand = Math.random();
        if (rand < 0.15) {
          addMessage(`[警告] 挖到岩浆了！烫烫烫！`);
          playSound('error');
        } else if (rand < 0.6) {
          const item = { ...VOLCANO_DIG_TYPES[Math.floor(Math.random() * VOLCANO_DIG_TYPES.length)], id: Math.random().toString(36).substring(7) } as Item;
          addItem(item);
          setActionResult(item);
          playSound('coin');
        } else {
          addMessage(`[系统] 只挖到了一些普通的火山灰。`);
        }
      }, 2000);
    }
  };

  const handleBuyDetector = () => {
    if (money >= 50 && !detectorOwned) {
      buyDetector();
      playSound('tada');
      addMessage(`[全岛广播] 玩家大聪明购买了古董探测器，准备大干一场！`);
    } else {
      playSound('error');
    }
  };

  const luckCost = 100 * Math.pow(2, luckLevel);
  const handleBuyLuck = () => {
    if (money >= luckCost) {
      buyLuckUpgrade();
      playSound('tada');
      addMessage(`[全岛广播] 玩家大聪明购买了锦鲤护符(Lv.${luckLevel + 1})，运气大增！`);
    } else {
      playSound('error');
    }
  };

  const rodSpeedCost = 100 * Math.pow(2, rodSpeedLevel);
  const rodZoneCost = 100 * Math.pow(2, rodZoneLevel);

  const sellItem = (item: Item) => {
    addMoney(item.value);
    removeItem(item.id);
    updateTask('sell', 1);
    playSound('coin');
  };

  const handleSellAll = () => {
    if (inventory.length > 0) {
      const totalValue = inventory.reduce((sum, item) => sum + item.value, 0);
      sellAll();
      playSound('coin');
      addMessage(`[系统] 一键出售了所有物品，获得 ${totalValue} 金币！`);
    }
  };

  const handleTravel = (islandId: string) => {
    if (islandId === currentIsland) return;
    setShowBoat(false);
    setSailing(true);
    playSound('splash');
    
    setTimeout(() => {
      setIsland(islandId);
      const islandName = ISLANDS.find(i => i.id === islandId)?.name;
      addMessage(`[系统] 你已抵达 ${islandName}！`);
    }, 1500); // Change island halfway through animation

    setTimeout(() => {
      setSailing(false);
    }, 3000); // Total animation time
  };

  const handleUnlockIsland = (islandId: string, cost: number) => {
    if (money >= cost) {
      unlockIsland(islandId, cost);
      playSound('tada');
      const islandName = ISLANDS.find(i => i.id === islandId)?.name;
      addMessage(`[系统] 成功解锁 ${islandName}！`);
    } else {
      playSound('error');
    }
  };

  return (
    <div className="absolute inset-0 pointer-events-none flex flex-col justify-between p-4">
      {/* Top Bar */}
      <div className="flex justify-between items-start pointer-events-auto">
        <div className="flex flex-col gap-2">
          <div className="flex gap-4">
            <div className="bg-white/90 px-4 py-2 rounded-2xl border-4 border-black shadow-[4px_4px_0_0_rgba(0,0,0,1)] flex items-center gap-2">
              <span className="text-2xl">💰</span>
              <span className="font-bold text-xl">{money}</span>
            </div>
            <div className="bg-white/90 px-4 py-2 rounded-2xl border-4 border-black shadow-[4px_4px_0_0_rgba(0,0,0,1)] flex items-center gap-2">
              <span className="text-2xl">{ISLANDS.find(i => i.id === currentIsland)?.icon}</span>
              <span className="font-bold text-xl">{ISLANDS.find(i => i.id === currentIsland)?.name}</span>
            </div>
          </div>
          {!user || user.isAnonymous ? (
            <button 
              onClick={handleLogin}
              className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-2xl border-4 border-black shadow-[4px_4px_0_0_rgba(0,0,0,1)] font-bold transition-transform active:translate-y-1 active:shadow-none flex items-center justify-center gap-2 w-fit"
            >
              登录保存进度
            </button>
          ) : (
            <div className="bg-white/90 px-4 py-2 rounded-2xl border-4 border-black shadow-[4px_4px_0_0_rgba(0,0,0,1)] flex items-center gap-2 w-fit">
              {user.photoURL && <img src={user.photoURL} alt="avatar" className="w-6 h-6 rounded-full" referrerPolicy="no-referrer" />}
              <span className="font-bold text-sm">{user.displayName}</span>
            </div>
          )}
        </div>
        
        <div className="flex flex-col gap-2 items-end">
          <button 
            onClick={() => setShowShop(true)}
            className="bg-yellow-400 hover:bg-yellow-500 text-white px-4 py-2 rounded-2xl border-4 border-black shadow-[4px_4px_0_0_rgba(0,0,0,1)] font-bold transition-transform active:translate-y-1 active:shadow-none flex items-center gap-2"
          >
            <Store size={24} />
            商店
          </button>
          <button 
            onClick={() => setShowInventory(true)}
            className="bg-blue-400 hover:bg-blue-500 text-white px-4 py-2 rounded-2xl border-4 border-black shadow-[4px_4px_0_0_rgba(0,0,0,1)] font-bold transition-transform active:translate-y-1 active:shadow-none flex items-center gap-2"
          >
            <span className="text-xl">🎒</span>
            背包 ({inventory.length})
          </button>
          <button 
            onClick={() => setShowBoat(true)}
            className="bg-orange-400 hover:bg-orange-500 text-white px-4 py-2 rounded-2xl border-4 border-black shadow-[4px_4px_0_0_rgba(0,0,0,1)] font-bold transition-transform active:translate-y-1 active:shadow-none flex items-center gap-2"
          >
            <Ship size={24} />
            航海
          </button>
          <button 
            onClick={() => setShowCollection(true)}
            className="bg-[#8b5a2b] hover:bg-[#6b4423] text-white px-4 py-2 rounded-2xl border-4 border-black shadow-[4px_4px_0_0_rgba(0,0,0,1)] font-bold transition-transform active:translate-y-1 active:shadow-none flex items-center gap-2"
          >
            <Book size={24} />
            图鉴
          </button>
        </div>
      </div>

      {/* Task UI */}
      {TASKS[currentTaskIndex] && (
        <div className="absolute top-24 left-4 pointer-events-auto z-40 bg-white/95 p-4 rounded-2xl border-4 border-black shadow-[4px_4px_0_0_rgba(0,0,0,1)] w-64">
          <div className="flex items-center gap-2 mb-2">
            <span className="text-2xl">📜</span>
            <h3 className="font-bold text-lg text-blue-900">任务指引</h3>
          </div>
          <p className="text-sm text-gray-700 mb-3 font-medium leading-tight">{TASKS[currentTaskIndex].desc}</p>
          
          {TASKS[currentTaskIndex].id !== 'done' && (
            <div className="flex flex-col gap-2">
              <div className="w-full bg-gray-200 h-3 rounded-full overflow-hidden border-2 border-black">
                <div 
                  className="bg-green-500 h-full transition-all duration-500" 
                  style={{ width: `${(taskProgress / TASKS[currentTaskIndex].target) * 100}%` }} 
                />
              </div>
              {taskProgress >= TASKS[currentTaskIndex].target ? (
                <button 
                  onClick={() => {
                    claimTaskReward();
                    playSound('tada');
                  }}
                  className="bg-green-400 hover:bg-green-500 text-white text-sm font-bold py-2 px-2 rounded-xl border-2 border-black animate-pulse flex items-center justify-center gap-1 shadow-sm active:scale-95 transition-transform"
                >
                  <CheckCircle size={16} />
                  领取奖励 💰{TASKS[currentTaskIndex].reward}
                </button>
              ) : (
                <span className="text-xs text-gray-500 text-right font-bold">{taskProgress} / {TASKS[currentTaskIndex].target}</span>
              )}
            </div>
          )}
        </div>
      )}

      {/* Broadcast Messages */}
      <div className="absolute top-20 left-1/2 -translate-x-1/2 flex flex-col items-center gap-1 pointer-events-none z-50">
        <AnimatePresence>
          {messages.map((msg, i) => {
            const isRainbow = msg.startsWith('🌈');
            return (
              <motion.div 
                key={i}
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className={`${isRainbow ? 'bg-gradient-to-r from-yellow-400 via-red-500 to-purple-500 text-white border-2 border-white shadow-[0_0_15px_rgba(255,215,0,0.8)] text-lg animate-pulse' : 'bg-black/60 text-white shadow-md'} px-4 py-1 rounded-full font-bold`}
              >
                {msg.replace('🌈', '')}
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>

      {/* Quest Timer */}
      {questActive && (
        <div className="absolute top-36 left-1/2 -translate-x-1/2 bg-red-500 text-white px-6 py-2 rounded-full font-bold text-xl border-4 border-black shadow-lg animate-pulse z-40 pointer-events-none">
          ⏳ 寻宝倒计时: {questTimeLeft}s
        </div>
      )}

      {/* Action Result Modal */}
      <AnimatePresence>
        {actionResult && (
          <motion.div 
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0, opacity: 0 }}
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-white p-6 rounded-2xl shadow-2xl border-4 border-black flex flex-col items-center gap-4 pointer-events-auto z-50 min-w-[250px]"
          >
            <div className="text-6xl">{actionResult.icon}</div>
            <div className="text-2xl font-bold">{actionResult.name}</div>
            <div className="text-gray-600 text-center max-w-[200px]">{actionResult.description}</div>
            
            <div className="flex gap-3 mt-4 w-full">
              {(actionResult.value >= 50 || actionResult.type === 'treasure') && (
                <button 
                  onClick={() => {
                    addMoney(50);
                    playSound('coin');
                    addMessage(`[系统] 分享成功！获得 50 金币奖励！`);
                    updateTask('share');
                    setActionResult(null);
                  }}
                  className="flex-1 bg-blue-400 px-4 py-2 rounded-xl font-bold border-2 border-black hover:bg-blue-500 active:scale-95 flex items-center justify-center gap-2 text-white"
                >
                  <Share2 size={18} />
                  炫耀
                </button>
              )}
              <button 
                onClick={() => setActionResult(null)}
                className="flex-1 bg-yellow-400 px-4 py-2 rounded-xl font-bold border-2 border-black hover:bg-yellow-500 active:scale-95"
              >
                收下
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Trapped Warning */}
      <AnimatePresence>
        {playerState === 'trapped' && (
          <motion.div 
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="absolute top-1/3 left-1/2 -translate-x-1/2 bg-red-500 text-white p-4 rounded-2xl shadow-2xl border-4 border-black flex items-center gap-4 pointer-events-auto z-40 animate-pulse"
          >
            <AlertTriangle size={40} />
            <div>
              <div className="font-bold text-xl">你被埋了！</div>
              <div className="text-sm">等待救援中... (5秒后自动脱困)</div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Chat UI */}
      <div className="absolute bottom-4 left-4 pointer-events-auto z-40 w-80">
        <div className="bg-black/40 rounded-xl p-2 mb-2 h-48 overflow-y-auto flex flex-col-reverse gap-1">
          {[...chatMessages].reverse().map(msg => (
            <div key={msg.id} className="text-white text-sm">
              <span className="font-bold text-yellow-300">{msg.displayName}: </span>
              <span className="break-words">{msg.text}</span>
            </div>
          ))}
        </div>
        <form onSubmit={handleSendChat} className="flex gap-2">
          <input 
            type="text" 
            value={chatInput}
            onChange={(e) => setChatInput(e.target.value)}
            placeholder="说点什么..." 
            className="flex-1 bg-white/90 rounded-xl px-3 py-2 border-2 border-black font-bold focus:outline-none focus:ring-2 focus:ring-yellow-400"
            maxLength={50}
          />
          <button type="submit" className="bg-blue-500 hover:bg-blue-600 text-white font-bold px-4 py-2 rounded-xl border-2 border-black active:scale-95">
            发送
          </button>
        </form>
      </div>

      {/* WASD Hint */}
      <div className="absolute bottom-32 left-1/2 -translate-x-1/2 text-white/80 font-bold text-lg pointer-events-none drop-shadow-md">
        使用 W A S D 移动
      </div>

      {/* Bottom Actions */}
      <div className="flex justify-center gap-6 pointer-events-auto pb-8">
        {playerState === 'fish_biting' ? (
          <button 
            onClick={handleCatchFish}
            className="flex flex-col items-center gap-2 p-4 rounded-2xl border-4 border-black shadow-[0_8px_0_0_rgba(0,0,0,1)] transition-all active:translate-y-2 active:shadow-none bg-red-500 hover:bg-red-600 text-white font-bold w-32 animate-pulse"
          >
            <Fish size={32} />
            <span className="text-lg">收竿！</span>
          </button>
        ) : (
          <button 
            onClick={handleFish}
            disabled={playerState !== 'idle'}
            className={`flex flex-col items-center gap-2 p-4 rounded-2xl border-4 border-black shadow-[0_8px_0_0_rgba(0,0,0,1)] transition-all active:translate-y-2 active:shadow-none ${playerState === 'fishing' ? 'bg-blue-300' : 'bg-blue-400 hover:bg-blue-500'} text-white font-bold w-32`}
          >
            <Fish size={32} />
            <span className="text-lg">{playerState === 'fishing' ? '钓鱼中...' : '甩竿钓鱼'}</span>
          </button>
        )}

        <button 
          onClick={handleDig}
          disabled={playerState !== 'idle'}
          className={`flex flex-col items-center gap-2 p-4 rounded-2xl border-4 border-black shadow-[0_8px_0_0_rgba(0,0,0,1)] transition-all active:translate-y-2 active:shadow-none ${playerState === 'digging' ? 'bg-orange-300' : 'bg-orange-400 hover:bg-orange-500'} text-white font-bold w-32`}
        >
          <Pickaxe size={32} />
          <span className="text-lg">{playerState === 'digging' ? '挖沙中...' : '挖宝'}</span>
        </button>

        <button 
          onClick={handleSpecialAction}
          disabled={playerState !== 'idle'}
          className={`flex flex-col items-center gap-2 p-4 rounded-2xl border-4 border-black shadow-[0_8px_0_0_rgba(0,0,0,1)] transition-all active:translate-y-2 active:shadow-none ${['building', 'shaking', 'mining'].includes(playerState) ? 'bg-purple-300' : 'bg-purple-400 hover:bg-purple-500'} text-white font-bold w-32`}
        >
          {currentIsland === 'sand' ? <Castle size={32} /> : currentIsland === 'forest' ? <TreePine size={32} /> : <Gem size={32} />}
          <span className="text-lg">
            {currentIsland === 'sand' ? (playerState === 'building' ? '堆沙堡...' : '堆沙堡') : 
             currentIsland === 'forest' ? (playerState === 'shaking' ? '摇树中...' : '摇树') : 
             (playerState === 'mining' ? '采矿中...' : '采矿')}
          </span>
        </button>
      </div>

      {/* Fishing Minigame UI */}
      {fishingGame?.active && (
        <div className="absolute bottom-40 left-1/2 -translate-x-1/2 w-64 h-8 bg-gray-200 rounded-full border-4 border-black overflow-hidden pointer-events-none z-40">
          {/* Success Zone */}
          <div 
            className="absolute top-0 bottom-0 bg-green-400"
            style={{ 
              left: `${50 - fishingGame.zoneSize / 2}%`, 
              width: `${fishingGame.zoneSize}%` 
            }}
          />
          {/* Slider */}
          <div 
            className="absolute top-0 bottom-0 w-2 bg-red-600 shadow-[0_0_10px_rgba(255,0,0,0.8)]"
            style={{ left: `calc(${fishingGame.sliderPos}% - 4px)` }}
          />
        </div>
      )}

      {/* Emote Menu */}
      <div className="absolute bottom-32 right-4 pointer-events-auto flex flex-col items-end gap-2 z-40">
        <AnimatePresence>
          {showEmotes && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.8, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.8, y: 20 }}
              className="bg-white/90 p-3 rounded-2xl border-2 border-black shadow-lg grid grid-cols-5 gap-2 mb-2"
            >
              {EMOTES.map(e => (
                <button key={e} onClick={() => handleEmote(e)} className="text-3xl hover:scale-125 transition-transform">
                  {e}
                </button>
              ))}
            </motion.div>
          )}
        </AnimatePresence>
        <button 
          onClick={() => setShowEmotes(!showEmotes)}
          className="bg-yellow-400 hover:bg-yellow-500 text-white p-3 rounded-full shadow-lg border-2 border-black font-bold transition-transform active:scale-95 flex items-center justify-center w-14 h-14"
        >
          <Smile size={28} />
        </button>
      </div>

      {/* Modals */}
      {showCollection && (
        <div className="absolute inset-0 bg-black/50 pointer-events-auto flex items-center justify-center z-50">
          <div className="bg-[#f4e4bc] w-[90%] max-w-4xl h-[80%] rounded-3xl border-4 border-[#8b5a2b] p-6 flex flex-col shadow-2xl">
            <div className="flex justify-between items-center mb-4 border-b-2 border-[#8b5a2b] pb-2">
              <h2 className="text-2xl font-bold text-[#5c3a21] flex items-center gap-2">
                <Book size={28} /> 收集图鉴 ({collection.length}/{ALL_ITEMS.length})
              </h2>
              <button onClick={() => setShowCollection(false)} className="p-2 hover:bg-black/10 rounded-full text-[#5c3a21]"><X /></button>
            </div>
            <div className="flex-1 overflow-y-auto pr-2 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 content-start">
              {ALL_ITEMS.map((item, idx) => {
                const isUnlocked = collection.includes(item.name);
                return (
                  <div key={idx} className={`p-3 rounded-xl border-2 flex flex-col items-center text-center transition-all ${isUnlocked ? 'bg-white border-[#8b5a2b] shadow-sm hover:scale-105' : 'bg-gray-200 border-gray-400 opacity-60'}`}>
                    <div className="text-4xl mb-2 filter drop-shadow-sm">{isUnlocked ? item.icon : '❓'}</div>
                    <div className="font-bold text-sm">{isUnlocked ? item.name : '未知物品'}</div>
                    {isUnlocked && <div className="text-xs text-gray-500 mt-1">{item.description}</div>}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {showInventory && (
        <div className="absolute inset-0 bg-black/50 pointer-events-auto flex items-center justify-center z-50">
          <div className="bg-white w-[90%] max-w-md h-[70%] rounded-3xl border-4 border-black p-6 flex flex-col">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-2xl font-bold">我的背包</h2>
              <button onClick={() => setShowInventory(false)} className="p-2 hover:bg-gray-200 rounded-full"><X /></button>
            </div>
            <div className="flex-1 overflow-y-auto grid grid-cols-4 gap-2 content-start">
              {inventory.map(item => (
                <div 
                  key={item.id} 
                  onClick={() => setShowingItem(showingItem?.id === item.id ? null : item)}
                  className={`aspect-square bg-gray-100 rounded-xl border-4 flex flex-col items-center justify-center relative group cursor-pointer transition-all ${showingItem?.id === item.id ? 'border-green-500 shadow-[0_0_15px_rgba(34,197,94,0.5)]' : 'border-gray-300 hover:border-black'}`}
                >
                  <span className="text-3xl">{item.icon}</span>
                  {showingItem?.id === item.id && (
                    <div className="absolute top-1 right-1 bg-green-500 text-white text-[10px] px-1 rounded font-bold">
                      展示中
                    </div>
                  )}
                  <div className="absolute hidden group-hover:flex flex-col -top-14 left-1/2 -translate-x-1/2 bg-black text-white text-xs p-2 rounded whitespace-nowrap z-10 text-center">
                    <span>{item.name} (价值: {item.value})</span>
                    <span className="text-gray-400 mt-1">点击{showingItem?.id === item.id ? '取消展示' : '展示'}</span>
                  </div>
                </div>
              ))}
              {inventory.length === 0 && <div className="col-span-4 text-center text-gray-500 mt-10">背包空空如也</div>}
            </div>
          </div>
        </div>
      )}

      {showShop && (
        <div className="absolute inset-0 bg-black/50 pointer-events-auto flex items-center justify-center z-50">
          <div className="bg-white w-[90%] max-w-md h-[80%] rounded-3xl border-4 border-black p-6 flex flex-col">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-2xl font-bold">黑心商店</h2>
              <button onClick={() => setShowShop(false)} className="p-2 hover:bg-gray-200 rounded-full"><X /></button>
            </div>

            <div className="flex gap-2 mb-4">
              <button 
                className={`flex-1 py-2 rounded-xl font-bold border-2 border-black ${shopTab === 'buy' ? 'bg-blue-400 text-white' : 'bg-gray-200'}`} 
                onClick={() => setShopTab('buy')}
              >
                购买道具
              </button>
              <button 
                className={`flex-1 py-2 rounded-xl font-bold border-2 border-black ${shopTab === 'sell' ? 'bg-yellow-400 text-white' : 'bg-gray-200'}`} 
                onClick={() => setShopTab('sell')}
              >
                出售战利品
              </button>
            </div>
            
            {shopTab === 'buy' && (
              <div className="flex-1 overflow-y-auto pr-2">
                <div className="mb-6 p-4 bg-yellow-100 rounded-xl border-2 border-yellow-400">
                  <h3 className="font-bold mb-2">购买道具</h3>
                  <div className="flex flex-col gap-2">
                    <button 
                      onClick={handleBuyDetector}
                      disabled={detectorOwned || money < 50}
                      className={`w-full py-3 rounded-xl font-bold border-2 border-black flex justify-between px-4 ${detectorOwned ? 'bg-gray-300 text-gray-500' : money >= 50 ? 'bg-green-400 hover:bg-green-500 text-white' : 'bg-gray-200 text-gray-500'}`}
                    >
                      <span>古董探测器 (滴滴响)</span>
                      <span>{detectorOwned ? '已拥有' : '💰 50'}</span>
                    </button>
                    <button 
                      onClick={handleBuyLuck}
                      disabled={money < luckCost}
                      className={`w-full py-3 rounded-xl font-bold border-2 border-black flex justify-between px-4 ${money >= luckCost ? 'bg-pink-400 hover:bg-pink-500 text-white' : 'bg-gray-200 text-gray-500'}`}
                    >
                      <span>锦鲤护符 Lv.{luckLevel + 1} (提升运气)</span>
                      <span>💰 {luckCost}</span>
                    </button>
                  </div>
                </div>

                <div className="mb-6 p-4 bg-blue-100 rounded-xl border-2 border-blue-400">
                  <h3 className="font-bold mb-2">鱼竿升级</h3>
                  <div className="flex flex-col gap-4">
                    {/* Rod Speed Upgrade */}
                    <div className="flex flex-col gap-1">
                      <div className="flex justify-between items-center">
                        <span className="font-bold text-sm">🎣 减速齿轮 (Lv.{rodSpeedLevel}/5)</span>
                        <button 
                          onClick={() => {
                            if (money >= rodSpeedCost && rodSpeedLevel < 5) {
                              buyRodSpeedUpgrade();
                              playSound('tada');
                            } else playSound('error');
                          }}
                          disabled={money < rodSpeedCost || rodSpeedLevel >= 5}
                          className={`px-3 py-1 rounded-lg font-bold text-white text-xs border-2 border-black ${money >= rodSpeedCost && rodSpeedLevel < 5 ? 'bg-blue-500 hover:bg-blue-600' : 'bg-gray-400'}`}
                        >
                          {rodSpeedLevel >= 5 ? '已满级' : `💰 ${rodSpeedCost}`}
                        </button>
                      </div>
                      <div className="w-full bg-blue-200 h-2 rounded-full overflow-hidden border border-blue-400">
                        <div className="bg-blue-600 h-full transition-all" style={{ width: `${(rodSpeedLevel / 5) * 100}%` }} />
                      </div>
                      <span className="text-[10px] text-gray-600">降低钓鱼滑块的移动速度</span>
                    </div>

                    {/* Rod Zone Upgrade */}
                    <div className="flex flex-col gap-1">
                      <div className="flex justify-between items-center">
                        <span className="font-bold text-sm">🎯 宽口鱼篓 (Lv.{rodZoneLevel}/5)</span>
                        <button 
                          onClick={() => {
                            if (money >= rodZoneCost && rodZoneLevel < 5) {
                              buyRodZoneUpgrade();
                              playSound('tada');
                            } else playSound('error');
                          }}
                          disabled={money < rodZoneCost || rodZoneLevel >= 5}
                          className={`px-3 py-1 rounded-lg font-bold text-white text-xs border-2 border-black ${money >= rodZoneCost && rodZoneLevel < 5 ? 'bg-green-500 hover:bg-green-600' : 'bg-gray-400'}`}
                        >
                          {rodZoneLevel >= 5 ? '已满级' : `💰 ${rodZoneCost}`}
                        </button>
                      </div>
                      <div className="w-full bg-green-200 h-2 rounded-full overflow-hidden border border-green-400">
                        <div className="bg-green-600 h-full transition-all" style={{ width: `${(rodZoneLevel / 5) * 100}%` }} />
                      </div>
                      <span className="text-[10px] text-gray-600">增大钓鱼时的绿色成功区域</span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {shopTab === 'sell' && (
              <div className="flex-1 overflow-hidden flex flex-col">
                <div className="flex justify-between items-center mb-2">
                  <h3 className="font-bold">出售战利品</h3>
                  {inventory.length > 0 && (
                    <button 
                      onClick={handleSellAll}
                      className="bg-blue-400 text-white px-3 py-1 rounded-lg text-sm font-bold border-2 border-black hover:bg-blue-500 active:scale-95"
                    >
                      一键出售
                    </button>
                  )}
                </div>
                <div className="flex-1 overflow-y-auto grid grid-cols-1 gap-2">
                  {inventory.map(item => (
                    <div key={item.id} className="flex items-center justify-between bg-gray-50 p-3 rounded-xl border-2 border-gray-200">
                      <div className="flex items-center gap-3">
                        <span className="text-2xl">{item.icon}</span>
                        <div>
                          <div className="font-bold">{item.name}</div>
                          <div className="text-xs text-gray-500">价值: {item.value}</div>
                        </div>
                      </div>
                      <button 
                        onClick={() => sellItem(item)}
                        className="bg-yellow-400 px-4 py-2 rounded-lg font-bold border-2 border-black hover:bg-yellow-500 active:scale-95"
                      >
                        卖出
                      </button>
                    </div>
                  ))}
                  {inventory.length === 0 && <div className="text-center text-gray-500 mt-4">没有可以卖的东西</div>}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {showBoat && (
        <div className="absolute inset-0 bg-blue-900/80 pointer-events-auto flex items-center justify-center z-50">
          <div className="bg-[#e6d5b8] w-[95%] max-w-4xl h-[80%] rounded-3xl border-8 border-[#8b5a2b] p-6 flex flex-col relative overflow-hidden shadow-2xl">
            {/* Map Texture Overlay */}
            <div className="absolute inset-0 opacity-20 pointer-events-none" style={{ backgroundImage: 'url("data:image/svg+xml,%3Csvg width=\'100\' height=\'100\' viewBox=\'0 0 100 100\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cpath d=\'M10 10 Q 30 20 50 10 T 90 10\' stroke=\'%23000\' fill=\'none\' opacity=\'0.5\'/%3E%3C/svg%3E")', backgroundSize: '100px 100px' }}></div>
            
            <div className="flex justify-between items-center mb-4 relative z-10">
              <h2 className="text-3xl font-bold text-[#5c3a21] flex items-center gap-2">
                <Ship size={32} /> 航海图
              </h2>
              <button onClick={() => setShowBoat(false)} className="p-2 hover:bg-black/10 rounded-full text-[#5c3a21]"><X size={32} /></button>
            </div>
            
            <div className="flex-1 relative bg-[#87CEEB] rounded-2xl border-4 border-[#5c3a21] overflow-hidden shadow-inner">
              {/* Radar Sweep */}
              <div className="absolute top-1/2 left-1/2 w-[200%] h-[200%] -translate-x-1/2 -translate-y-1/2 z-[15] pointer-events-none opacity-20 overflow-hidden">
                <motion.div 
                  animate={{ rotate: 360 }} 
                  transition={{ repeat: Infinity, duration: 4, ease: "linear" }}
                  className="w-full h-full rounded-full"
                  style={{ background: 'conic-gradient(from 0deg, transparent 70%, rgba(0, 255, 0, 1) 100%)' }}
                />
              </div>

              {/* Clouds/Fog for locked areas */}
              <div className="absolute inset-0 pointer-events-none z-10">
                {ISLANDS.map(island => {
                  if (unlockedIslands.includes(island.id)) return null;
                  return (
                    <div 
                      key={`fog-${island.id}`}
                      className="absolute w-48 h-48 bg-white/90 rounded-full blur-xl"
                      style={{ left: `calc(${island.x}% - 6rem)`, top: `calc(${island.y}% - 6rem)` }}
                    />
                  );
                })}
              </div>

              {/* Islands */}
              {ISLANDS.map(island => {
                const isUnlocked = unlockedIslands.includes(island.id);
                const isCurrent = currentIsland === island.id;
                
                return (
                  <div 
                    key={island.id}
                    className="absolute transform -translate-x-1/2 -translate-y-1/2 flex flex-col items-center gap-2 z-20"
                    style={{ left: `${island.x}%`, top: `${island.y}%` }}
                  >
                    <div className="relative">
                      {/* Level Badge */}
                      <div className="absolute -top-2 -right-2 w-6 h-6 bg-gray-800 text-white rounded-full flex items-center justify-center text-xs font-bold border-2 border-white z-30 shadow-sm">
                        {island.level}
                      </div>
                      {isCurrent && (
                        <motion.div 
                          animate={{ y: [0, -10, 0] }}
                          transition={{ repeat: Infinity, duration: 1.5 }}
                          className="absolute -top-10 left-1/2 -translate-x-1/2 text-2xl drop-shadow-md z-30"
                        >
                          👇
                        </motion.div>
                      )}
                      <button
                        onClick={() => isUnlocked ? handleTravel(island.id) : null}
                        className={`w-20 h-20 rounded-full border-4 shadow-xl flex items-center justify-center text-4xl transition-transform ${
                          isCurrent ? 'border-yellow-400 bg-yellow-100 scale-110' : 
                          isUnlocked ? 'border-green-500 bg-green-100 hover:scale-110 cursor-pointer' : 
                          'border-gray-500 bg-gray-300 grayscale cursor-default'
                        }`}
                      >
                        {island.icon}
                      </button>
                    </div>
                    
                    <div className="bg-white/90 px-3 py-1 rounded-lg border-2 border-black font-bold text-sm whitespace-nowrap shadow-md z-20">
                      {island.name}
                    </div>

                    {!isUnlocked && (
                      <div className="mt-2 bg-[#f0f0c0] p-2 rounded-xl border-2 border-[#d0c090] shadow-lg flex flex-col gap-2 items-center z-30">
                        <button
                          onClick={() => handleUnlockIsland(island.id, island.cost)}
                          disabled={money < island.cost}
                          className={`px-6 py-2 rounded-lg font-bold border-b-4 border-black text-sm shadow-sm transition-transform active:translate-y-1 active:border-b-0 flex flex-col items-center ${
                            money >= island.cost ? 'bg-[#8BC34A] hover:bg-[#7CB342] text-white cursor-pointer' : 'bg-gray-400 text-white cursor-not-allowed'
                          }`}
                        >
                          <span className="text-xs opacity-90">探索</span>
                          <span className="flex items-center gap-1 text-lg">💰 {island.cost}</span>
                        </button>
                      </div>
                    )}
                    
                    {isUnlocked && !isCurrent && (
                      <div className="mt-1 px-3 py-1 rounded-full bg-blue-500 text-white font-bold text-xs border-2 border-black shadow-md z-20">
                        点击前往
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Sailing Transition Overlay */}
      <AnimatePresence>
        {isSailing && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5 }}
            className="absolute inset-0 bg-blue-500 z-[100] flex items-center justify-center overflow-hidden pointer-events-auto"
          >
            {/* Moving Waves */}
            <motion.div 
              animate={{ x: ['0%', '-50%'] }}
              transition={{ repeat: Infinity, duration: 2, ease: "linear" }}
              className="absolute inset-0 opacity-30 flex"
              style={{ width: '200%' }}
            >
              <div className="w-1/2 h-full" style={{ backgroundImage: 'radial-gradient(circle at 50% 50%, white 2px, transparent 3px)', backgroundSize: '50px 50px' }}></div>
              <div className="w-1/2 h-full" style={{ backgroundImage: 'radial-gradient(circle at 50% 50%, white 2px, transparent 3px)', backgroundSize: '50px 50px' }}></div>
            </motion.div>

            {/* Sailing Boat */}
            <motion.div
              initial={{ x: -300, y: 0, rotate: -5 }}
              animate={{ 
                x: window.innerWidth + 300, 
                y: [0, -20, 0, 20, 0],
                rotate: [-5, 5, -5, 5, -5]
              }}
              transition={{ 
                x: { duration: 3, ease: "easeInOut" },
                y: { repeat: Infinity, duration: 1, ease: "easeInOut" },
                rotate: { repeat: Infinity, duration: 1, ease: "easeInOut" }
              }}
              className="text-9xl drop-shadow-2xl"
            >
              ⛵
            </motion.div>
            
            <div className="absolute bottom-20 text-white font-bold text-3xl tracking-widest animate-pulse drop-shadow-md">
              航行中...
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Fake Ad Modal */}
      <AnimatePresence>
        {adState.playing && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-black z-[200] flex flex-col items-center justify-center text-white pointer-events-auto"
          >
            <div className="absolute top-6 right-6">
              {adState.timeLeft > 0 ? (
                <div className="bg-gray-800 rounded-full w-12 h-12 flex items-center justify-center text-gray-400 font-bold border-2 border-gray-600">
                  {adState.timeLeft}
                </div>
              ) : (
                <button 
                  onClick={() => {
                    if (adState.reward) adState.reward();
                    setAdState({ playing: false, timeLeft: 0, reward: null });
                  }}
                  className="bg-gray-700 hover:bg-gray-600 rounded-full p-3 border-2 border-gray-500 transition-transform hover:scale-110"
                >
                  <X size={24} />
                </button>
              )}
            </div>
            
            <div className="text-6xl mb-6 animate-bounce">📺</div>
            <h2 className="text-3xl font-bold mb-2 text-yellow-400">精彩广告放送中...</h2>
            <p className="text-gray-400 mb-8">（假装这里有一个很无聊的买量广告）</p>
            
            {/* Fake ad content */}
            <div className="w-80 h-80 bg-gray-800 rounded-2xl flex flex-col items-center justify-center border-4 border-gray-700 relative overflow-hidden shadow-2xl">
               <motion.div 
                 animate={{ x: [-120, 120] }} 
                 transition={{ repeat: Infinity, duration: 2, ease: "linear" }} 
                 className="text-7xl absolute top-1/3"
               >
                 🏃‍♂️
               </motion.div>
               <motion.div 
                 animate={{ x: [-120, 120] }} 
                 transition={{ repeat: Infinity, duration: 2, ease: "linear", delay: 0.5 }} 
                 className="text-7xl absolute top-1/3"
               >
                 🧟
               </motion.div>
               <div className="absolute bottom-6 bg-red-600 px-4 py-2 rounded-full text-white font-bold text-xl shadow-lg animate-pulse">
                 LV.1 菜鸟 vs LV.99 老大
               </div>
            </div>
            
            <div className="absolute bottom-10 text-gray-500 text-sm">
              看完广告即可获得奖励
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

