/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { GameScene } from './Scene';
import { GameUI } from './GameUI';
import { useGameStore } from './store';
import { MultiplayerSync } from './MultiplayerSync';

export default function App() {
  const currentIsland = useGameStore(state => state.currentIsland);
  
  // Different background colors for different islands
  const bgColors: Record<string, string> = {
    sand: 'bg-[#87CEEB]', // Sky blue
    forest: 'bg-[#4B5320]', // Dark green/foggy
    volcano: 'bg-[#4A0E0E]' // Dark red
  };
  
  const bgColor = bgColors[currentIsland] || bgColors.sand;

  return (
    <div className={`w-full h-screen ${bgColor} relative overflow-hidden font-sans select-none transition-colors duration-1000`}>
      <MultiplayerSync />
      <GameScene />
      <GameUI />
    </div>
  );
}
